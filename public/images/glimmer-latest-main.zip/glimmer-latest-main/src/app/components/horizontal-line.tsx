import React from "react";

const HorizontalLine = () => {
  return <div className="w-[1000px] h-[2px] bg-neutral mx-auto mb-3" />;
};

export default HorizontalLine;
