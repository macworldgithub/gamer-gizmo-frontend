import ComingSoon from "@/common/comming-soon";
import React from "react";

const Register = () => {
  return <ComingSoon />;
};

export default Register;
